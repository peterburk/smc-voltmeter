//
//  main.m
//  GraphKitDemo
//
//  Created by Dave Jewell on 06/11/2008.
//  Copyright Cocoa Secrets 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
