#!/bin/bash
/Users/peter/bin/System/Voltmeter/smc -l | grep "VD0R" | cut -d ' ' -f 7
