smcFanControl
=============

smcFanControl lets the user set a minimum speed for built-in fans. It allows you to increase your minimum fan speed to make your Intel Mac run cooler. In order to not damage your machine, smcFanControl does not let you set a minimum speed to a value below Apple's defaults.

![My image](https://dl.dropbox.com/u/363242/screenshots/smc_screenshot.png)

Requirements: Intel Mac / OS X 10.5 or higher 

Compiled version: http://www.eidac.de/smcfancontrol/smcfancontrol_2_4.zip

FAQ / More info: Found in project under "Ressources/*.lproj/F.A.Q.rtf" or included in above .zip

License: GPL 2
